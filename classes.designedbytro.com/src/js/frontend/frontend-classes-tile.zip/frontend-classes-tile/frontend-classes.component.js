angular.
module('frontendClasses').
component('frontendClasses', {
	templateUrl: "frontend-classes.template.html",
	controller: ['dataFactory', function(dataFactory) {
			var self = this;
	
			self.classes = dataFactory.classes.query();
		}] 	
});
angular.
module('frontendClasses').
component('frontendClassesTile', {
	bindings: {
  		item: '<',
  		index: '@',
  		classes: '='
  	},
	templateUrl: "frontend-classes-tile.template.html",
	controller: function() {
		if(this.index % 7 == 1 || this.index % 7 == 5) {
			this.size = 'wide';
			this.classes = 'all-66 tiny-100 small-100';
		} else {
			this.size = 'square';
			this.classes = 'all-33 tiny-100 small-100';
		}
	}
});
// angular.
// module('frontendClasses').
// component('frontendClassesSummary', {
// 	bindings: {
//   		summary: '<'
//   	},
// 	templateUrl: "frontend-classes-summary.template.html",
// 	controller: ['dataFactory', function ClassesController(dataFactory) {
// 			var self = this;
	
// 			dataFactory.getClasses().then(function(response) {
// 				self.classes = response.data;
// 			});
// 		}] 
// });
angular.
module('frontendClasses').
component('frontendClass', {
	    templateUrl: "frontend-classes-class.template.html",
	    controller: ['$routeParams', 'dataFactory', '$q', 'update', function ClassesController($routeParams, dataFactory, $q, update) {
			var self = this;
			var classid = $routeParams.classid;

			self.class = {};
			self.class.id = classid;
			self.class.title = "ERROR";

			self.class = dataFactory.classes.get({id:classid});
			self.participants = dataFactory.participants.query();
	
			$q.all(
				[
					self.class.$promise,
					self.participants.$promise
				]
				).then(function(response){
					//self.class = response[0];
					//self.participants = response[1];

					self.sessions = self.class.sessions;

					angular.forEach(self.sessions, function(session){
						//check for waitlist
						var classsession = self.class.id + "#" + session.id;
						var size = session.size;
						var participants = self.participants.filter(function(item) {
							 return item.CourseSession == classsession && item.PaymentStatus != "Unenrolled"; 
						});

						if(participants.length >= size) {
							session.waitlist = true;
						} else {
							session.waitlist = false;
						}

						return session;
					});
				}
				); 

			self.alert = false;

			self.submit = function(classItem) {
				var participant = new dataFactory.participants(classItem.participant);

				participant.CourseSession = classItem.key + "#" + classItem.session.key;
				participant.Cost = classItem.price;
				participant.ClassName = classItem.title;
				participant.SessionName = classItem.session.title;
				participant.Date = classItem.session.date;
				participant.Type = classItem.type;

				console.log(participant);

				participant.$save(function() {
					var newStatus;
					if(classItem.session.waitlist) {
						newStatus = 'Wait List';
					} else {
						newStatus = 'Registered';
					}

					data = update.status(participant.participants, newStatus);

					dataFactory.participants.update({
						coursesession: participant.participants.CourseSession, 
					    emailaddress: participant.participants.EmailAddress
					}, data); 
				});

				self.alert = true;
			};
		}]			
});